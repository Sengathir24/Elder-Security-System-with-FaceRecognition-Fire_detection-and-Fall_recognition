import cv2
class facerecognition():
    def __init__(self):
        self.face_cascade = cv2.CascadeClassifier(r"C:\Users\Faster\Downloads\Fall_Detection-main\Elder Security System\FaceRecognition\haarcascade_frontalface_default.xml")
        self.face_model = cv2.face.LBPHFaceRecognizer_create()
        self.names = ["vishal"]
        self.face_model.read(r"C:\Users\Faster\Downloads\Fall_Detection-main\Elder Security System\FaceRecognition\trained_model.xml")
    def person_recognize(self,frame): 
        self.frame=frame   
        gray = cv2.cvtColor(self.frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
        person=""
        for (x, y, w, h) in faces:
            face_roi = gray[y:y + h, x:x + w]
            label_id, confidence = self.face_model.predict(face_roi)
            cv2.rectangle(self.frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            if confidence < 213.999999999999 and label_id == 0:
                person=self.names[label_id]
            else:
                person='Unknown'
            cv2.putText(self.frame, person, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
        cv2.imshow('Face Recognizer', self.frame)
        return(person)

    
