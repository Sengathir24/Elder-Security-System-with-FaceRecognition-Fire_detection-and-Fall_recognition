import cv2
import playsound
import threading
from playsound import playsound
class firedetection():
    def __init__(self):
        self.fire_cascade = cv2.CascadeClassifier('FireDetection/fire_detection_cascade_model.xml')
    def play_alarm_sound_function(self):
        try:
            playsound("FireDetection/Fire_alarm.mp3", True)
            print("Fire alarm end")
        except Exception as e:
            print("Error playing alarm sound:", e)
    def fire_detector(self,frame):
        self.frame=frame
        fire = self.fire_cascade.detectMultiScale(self.frame, 1.2, 5)
        for (x, y, w, h) in fire:
            cv2.rectangle(self.frame, (x-20, y-20), (x+w+20, y+h+20), (255, 0, 0), 2)
            print("Fire alarm initiated")
            threading.Thread(target=self.play_alarm_sound_function).start()
        cv2.imshow('Fire Detector', self.frame)
        
